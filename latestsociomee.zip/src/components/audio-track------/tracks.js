import imgSrc1 from "./assets/image-1.jpg";
import audio1 from "./assets/audio-1.mp3";

export default [
  {
    title: "Esset's Adventures",
    artist: "Ariana Grande",
    audioSrc: audio1,
    image: imgSrc1,
    color: "#00aeb0"
  }
];
