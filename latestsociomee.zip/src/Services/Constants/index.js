// Category List when user will create new group
export const GET_ALL_GROUP_CATEGORY = "GET_ALL_GROUP_CATEGORY";

// Use to create new group
export const GET_ALL_CREATE_GROUP = "GET_ALL_CREATE_GROUP";

